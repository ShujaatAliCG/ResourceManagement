# Spring-Boot-Employee-Management

http://localhost:8080/welcome/employees/pages

##Spring Security Lognin Screen- admin/admin, user/user
 
![screenshot-1](https://cloud.githubusercontent.com/assets/16677013/16341021/a814d312-39f0-11e6-8f7f-6a55b09c8c64.png)

##Employee list paging
  
![screenshot](https://cloud.githubusercontent.com/assets/16677013/16340898/10b00ad2-39f0-11e6-9f4d-030322ec30ed.png)

##Add Employee

![screenshot-5](https://cloud.githubusercontent.com/assets/16677013/16341018/a811c67c-39f0-11e6-94ef-8d7b54804ba9.png)

##Edit Employee

![screenshot-4](https://cloud.githubusercontent.com/assets/16677013/16341020/a812308a-39f0-11e6-874b-1523d632aa03.png)

