package com.hr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeSpringbootApplication.class, args);
	}
}
